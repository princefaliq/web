<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class model_has_role extends Model
{
    //
}
